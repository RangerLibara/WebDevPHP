<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "activity4db";


$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

?>